# Esp32_Vue_Example

Demo project that shows how to use Vue.js together with an ESP32 Microcontroller using the Arduino IDE. The detailed description can be found [in the Vue application](https://pschatzmann.github.io/esp32_vue_example/vue-demo/dist/index.html#/)

- The vue-demo directory contains the Vue.js application 
- The esp32_vue_example.ino	is the Arduino Server Sketch for the ESP32
