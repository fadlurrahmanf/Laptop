#ifndef _secrets_hpp_
#define _secrets_hpp_

const char* WIFI_SSID = "yourWifi";
const char* WIFI_PASSWORD = "yourPassword123";
const char* OTA_PASSWORD = "yourPassword000";

const char* MQTT_SERVER_IP = "192.168.1.1";

#endif
/*
 ignore changes with: git update-index --assume-unchanged include/secrets.h
 undo with: git update-index --no-assume-unchanged include/secrets.h
*/