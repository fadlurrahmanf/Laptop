IoThings Arduino Library for
Analog Devices AD7150 Breakout
==============================================================

Here is all the code you need to use this sensor

Feel free to fork, or submit any improvements via a pull request